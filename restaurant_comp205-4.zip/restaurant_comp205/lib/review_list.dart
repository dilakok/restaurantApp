import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class ReviewList extends StatefulWidget {
  const ReviewList({Key? key}) : super(key: key);

  @override
  _ReviewListState createState() => _ReviewListState();
}

class _ReviewListState extends State<ReviewList> {
  final textController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    CollectionReference reviewBook =
        FirebaseFirestore.instance.collection('reviewBook');

    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Reviews'),
        ),
        body: Center(
          child: StreamBuilder(
              stream:
                  reviewBook.orderBy('timestamp', descending: true).snapshots(),
              builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
                if (!snapshot.hasData) {
                  return Center(child: Text('Loading'));
                }
                return ListView(
                  children: snapshot.data!.docs.map((reviewPack) {
                    return Center(
                      child: ListTile(
                        leading: Text(reviewPack['rating'].toString()),
                        title: Text(reviewPack['text']),
                        subtitle: Text(reviewPack['timestamp'].toString()),
                        onLongPress: () {
                          reviewPack.reference.delete();
                        },
                      ),
                    );
                  }).toList(),
                );
              }),
        ),
      ),
    );
  }
}
