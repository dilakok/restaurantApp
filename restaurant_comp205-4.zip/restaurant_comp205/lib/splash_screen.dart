import 'package:flutter/material.dart';

import 'package:menu/login.dart';
import 'package:splash_screen_view/SplashScreenView.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Widget example3 = SplashScreenView(
      navigateRoute: Login(),
      duration: 3000,
      imageSize: 130,
      pageRouteTransition: PageRouteTransition.Normal,
      imageSrc: "images/appstore.jpeg",
      speed: 100,
      text: "Bon Appetit",
      textType: TextType.TyperAnimatedText,
      textStyle: TextStyle(
        fontSize: 30.0,
      ),
      backgroundColor: Colors.white,
    );

    return MaterialApp(
      title: 'Bon Appetit',
      home: example3,
    );
  }
}
