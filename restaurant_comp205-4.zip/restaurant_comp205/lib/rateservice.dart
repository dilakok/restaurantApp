import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'review_list.dart';
import 'dart:async';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

void main() async {
  await Firebase.initializeApp();
  runApp(const MaterialApp(home: RateService()));
}

class RateService extends StatefulWidget {
  const RateService({Key? key}) : super(key: key);

  @override
  _RateServiceState createState() => _RateServiceState();
}

class _RateServiceState extends State<RateService> {
  double rating = 0;
  final textController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    CollectionReference reviewBook =
        FirebaseFirestore.instance.collection('reviewBook');

    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Leave a Review!'),
            RatingBar.builder(
              minRating: 1,
              itemBuilder: (context, _) => const Icon(
                Icons.star,
                color: Colors.amber,
              ),
              itemPadding: const EdgeInsets.symmetric(horizontal: 4),
              updateOnDrag: true,
              onRatingUpdate: (rating) {
                setState(() {
                  this.rating = rating;
                });
              },
            ),
            TextField(
              controller: textController,
            ),
            TextButton(
                onPressed: () {
                  reviewBook.add({
                    'text': textController.text,
                    'timestamp': DateTime.now(),
                    'rating': rating,
                  });
                  textController.clear();
                },
                child: Text('Submit Review')),
            SizedBox(height: 100),
            TextButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => ReviewList()),
                  );
                },
                child: Text('See the Rest of the Reviews'))
          ],
        ),
      ),
    );
  }

  Future<void> _showNotification() async {
    const AndroidNotificationDetails androidPlatformChannelSpecifics =
        AndroidNotificationDetails('your channel id', 'your channel name',
            channelDescription: 'your channel description',
            importance: Importance.max,
            priority: Priority.high,
            ticker: 'ticker');
    const NotificationDetails platformChannelSpecifics =
        NotificationDetails(android: androidPlatformChannelSpecifics);
    await flutterLocalNotificationsPlugin.show(
        0, 'plain title', 'plain body', platformChannelSpecifics);
  }
}
