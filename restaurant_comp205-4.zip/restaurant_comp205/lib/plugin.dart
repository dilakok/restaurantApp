import 'package:battery_plus_web/battery_plus_web.dart';
import 'package:flutter_web_plugins/flutter_web_plugins.dart';

void registerPlugins(Registrar registrar) {
  BatteryPlusPlugin.registerWith(registrar);
  registrar.registerMessageHandler();
}
