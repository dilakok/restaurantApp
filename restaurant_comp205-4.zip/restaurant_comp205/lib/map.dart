import 'dart:async';

import 'package:permission_handler/permission_handler.dart';
import 'package:geolocator/geolocator.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class MapScreen extends StatefulWidget {
  @override
  _MapScreenState createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {

  Completer<GoogleMapController> _controller = Completer();
  bool dataArrived = false;

 //function get user log and lat once open map
  Future getLocation() async{
    PermissionStatus permission = await Permission.location.request();
    if(permission.isDenied){
      Navigator.pop(context);
    }
    Position position = await Geolocator.getLastKnownPosition()??
      await Geolocator.getCurrentPosition();
    setState(() {
      _kUserPlex = CameraPosition(
        target: LatLng(position.latitude, position.longitude),
        zoom: 14.4746,
      );
      dataArrived = true;
    });
  }

  @override
  void initState(){
    super.initState();
    getLocation();
  }


  late CameraPosition _kUserPlex;

  // markers object (AGU)
  static final Marker _kGooglePlexMarker =
  Marker(markerId: MarkerId('_kGooglePlex'),
    infoWindow: InfoWindow(title: 'Google Plex'),
    icon: BitmapDescriptor.defaultMarker,
    position: LatLng(38.7371, 35.4735), //AGU
  );


   static final CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng(38.734802, 35.467987), //Kayseri
    zoom: 14.4746,
  );

  static final Marker _kUserMarker =
  Marker(markerId: MarkerId('_kUserPlex'),
    infoWindow: InfoWindow(title: 'Google Plex'),
    icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
    // position: , //AGU
  );

  static final CameraPosition _kAgu = const CameraPosition(
      bearing: 192.8334901395799,
      target: LatLng(38.734802, 35.467987), //AGU
      tilt: 59.440717697143555,
      zoom: 19.151926040649414,
  );



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // body: dataArrived == false?
      //       const Center(child: CircularProgressIndicator(),):
    body: GoogleMap(
    mapType: MapType.normal,
    markers: {_kGooglePlexMarker},
    initialCameraPosition: _kGooglePlex,
      onMapCreated: (GoogleMapController controller) {
        _controller.complete(controller);
      },
    ),

    );

  }

}

