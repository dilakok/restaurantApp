import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'home.dart';
import 'login.dart';
import 'auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class Signup extends StatefulWidget {
  @override
  _SignupState createState() => _SignupState();
}

class _SignupState extends State<Signup> {
  TextEditingController _emailController = TextEditingController();
  TextEditingController _passwordController = TextEditingController();
  TextEditingController _usernameController = TextEditingController();

  late final String email;
  String password = '     ';
  late final String username;

  String locationMessage = "";

  void authenticateAndSignUp() async {
    String x = await Auth()
        .sign_up(_emailController.text.trim(), _passwordController.text.trim());

    if (x == 'true') {
      await saveDatatoFirestore();
    }
  }

  //function to store info to firestore
  Future saveDatatoFirestore() async {
    print("Hola");
    FirebaseFirestore.instance
        .collection("customers")
        .doc(Auth().userUID)
        .set(<String, dynamic>{
      "customerEmail": _emailController.text.trim(),
      "customerUserName": _usernameController.text.trim(),
      "address": locationMessage,
    });
    print("Hola2");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Column(
        children: <Widget>[
          Container(
            child: Container(
              padding: EdgeInsets.fromLTRB(15.0, 110.0, 0.0, 0.0),
              child: Text(
                'Sign Up',
                style: TextStyle(
                  fontFamily: 'Pacifico',
                  fontSize: 80.0,
                ),
              ),
            ),
          ),
          Container(
            padding: EdgeInsets.only(top: 35.0, left: 20.0, right: 20.0),
            child: Column(
              children: <Widget>[
                TextField(
                  textAlign: TextAlign.center,
                  controller: _emailController,
                  decoration: InputDecoration(
                    focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: Color(0xFFcaa052)),
                    ),
                    labelText: 'EMAIL',
                    labelStyle: TextStyle(
                      fontFamily: 'Alegreya Sans',
                      fontWeight: FontWeight.bold,
                      color: Color(0xFFcaa052),
                    ),
                  ),
                ),
                SizedBox(
                  height: 10.0,
                ),
                TextField(
                  textAlign: TextAlign.center,
                  controller: _passwordController,
                  decoration: InputDecoration(
                    focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: Color(0xFFcaa052)),
                    ),
                    labelText: 'PASSWORD',
                    labelStyle: TextStyle(
                      fontFamily: 'Alegreya Sans',
                      fontWeight: FontWeight.bold,
                      color: Color(0xFFcaa052),
                    ),
                  ),
                  obscureText: true,
                ),
                SizedBox(
                  height: 10.0,
                ),
                TextField(
                  textAlign: TextAlign.center,
                  controller: _usernameController,
                  decoration: InputDecoration(
                    focusedBorder: UnderlineInputBorder(
                      borderSide: BorderSide(color: Color(0xFFcaa052)),
                    ),
                    labelText: 'USERNAME',
                    labelStyle: TextStyle(
                      fontFamily: 'Alegreya Sans',
                      fontWeight: FontWeight.bold,
                      color: Color(0xFFcaa052),
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 50.0,
          ),
          Container(
            height: 40.0,
            width: 400.0,
            child: Material(
              borderRadius: BorderRadius.circular(20.0),
              shadowColor: Color(0xFFffffb1),
              color: Color(0xFFffd180),
              elevation: 7.0,
              child: InkWell(
                onTap: () async {
                  var x = await Auth()
                      .sign_up(_emailController.text, _passwordController.text);
                  if (x == 'true') {
                    await FirebaseFirestore.instance
                        .collection("customers")
                        .doc(Auth().userUID)
                        .set(<String, dynamic>{
                      "customerEmail": _emailController.text.trim(),
                      "customerUserName": _usernameController.text.trim(),
                      "address": locationMessage,
                    });

                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(builder: (context) => Home()),
                      (route) => false,
                    );
                  }
                  print(x);
                },
                child: Center(
                  child: Text(
                    'SIGNUP',
                    style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Alegreya Sans',
                    ),
                  ),
                ),
              ),
            ),
          ),
          SizedBox(
            height: 20.0,
          ),
          Container(
            height: 40.0,
            width: 400.0,
            color: Colors.transparent,
            child: Container(
              decoration: BoxDecoration(
                border: Border.all(
                  color: Colors.black,
                  style: BorderStyle.solid,
                  width: 1.0,
                ),
                color: Colors.transparent,
                borderRadius: BorderRadius.circular(20.0),
              ),
              child: GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => Login()),
                  );
                },
                child: Center(
                  child: Text(
                    'Already A Member',
                    style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Alegreya Sans',
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
