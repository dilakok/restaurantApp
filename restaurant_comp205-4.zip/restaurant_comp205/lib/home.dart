import 'package:flutter/material.dart';
import 'package:menu/preparation.dart';
import 'login.dart';
import 'package:menu/menu/menu.dart';
import 'reservation.dart';
import 'adress_screen.dart';
import 'battery_main.dart ';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        automaticallyImplyLeading:
            false, //don't display the automatic BackButton
        backgroundColor: Color(0xFFf9c42d),
        title: Center(
          child: Text(
            'Bon Appetit!',
            style: TextStyle(
              fontFamily: 'Pacifico',
              color: Colors.white,
            ),
          ),
        ),
        actions: [
          PopupMenuButton<int>(
            onSelected: (item) => onSelected(context, item),
            itemBuilder: (context) => [
              PopupMenuItem<int>(value: 0, child: Text('Track Your Meal')),
              PopupMenuItem<int>(
                value: 1,
                child: Text('Sign Out'),
              ),
              PopupMenuItem<int>(
                value: 2,
                child: Text('Show battery'),
              ),
            ],
          ),
        ],
      ),

      // wrap cards with inkwell
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              SizedBox(
                height: 15.0,
              ),
              InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const Reservation()),
                  );
                },
                child: Card(
                  color: Color(0xFFffd180),
                  child: SizedBox(
                    height: 180.0,
                    width: 400.0,
                    child: Center(
                      child: ListTile(
                        leading: Image.asset(
                          'images/table-reservation.png',
                          width: 40.0,
                          height: 40.0,
                        ),
                        title: Text(
                          'Reserve A Table',
                          style: TextStyle(
                            fontSize: 30.0,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        trailing: Icon(
                          Icons.chevron_right,
                          size: 60.0,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 10.0,
              ),
              InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => AddressScreen()),
                  );
                },
                child: Card(
                  color: Color(0xFFffd180),
                  child: SizedBox(
                    height: 180.0,
                    width: 400.0,
                    child: Center(
                      child: ListTile(
                        leading: Image.asset(
                          'images/delivery-man.png',
                          width: 40.0,
                          height: 40.0,
                        ),
                        title: Text(
                          'Order',
                          style: TextStyle(
                            fontSize: 30.0,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        trailing: Icon(
                          Icons.chevron_right,
                          size: 60.0,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 10.0,
              ),
              InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => Menu()),
                  );
                },
                child: Card(
                  color: Color(0xFFffd180),
                  child: SizedBox(
                    height: 180.0,
                    width: 400.0,
                    child: Center(
                      child: ListTile(
                        leading: Image.asset(
                          'images/take-away.png',
                          width: 40.0,
                          height: 40.0,
                        ),
                        title: Text(
                          'Take Away',
                          style: TextStyle(
                            fontSize: 30.0,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        trailing: Icon(
                          Icons.chevron_right,
                          size: 60.0,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // PopUpMenuButton cases
  void onSelected(BuildContext context, int item) {
    switch (item) {
      case 0:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => Preparation()),
        );
        break;
      case 1:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => Login()),
        );
        break;
      case 2:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => BatteryPage()),
        );
        break;
    }
  }
}
