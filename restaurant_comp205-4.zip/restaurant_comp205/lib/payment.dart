import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'preparation.dart';
import 'package:menu/menu/constants.dart';
import 'map.dart';
import 'package:flutter_windowmanager/flutter_windowmanager.dart';

//test@team.com
class CartPage extends StatelessWidget {
  const CartPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFc29400),
      appBar: AppBar(
          backgroundColor: appBarBackgroundColor,
          // title: Center(
          title: Text(
            'Payment Method',
            style: appBarTextStyle,
          )
          //),
          ),
      body: SingleChildScrollView(
        child: SafeArea(
          child: new Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: <Widget>[
              Card(
                child: Row(
                  //mainAxisSize: ,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    SizedBox(
                      width: 100,
                      height: 100,
                      child: Image.network(
                        'https://images.unsplash.com/photo-1610970878459-a0e464d7592b?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1848&q=80',
                        fit: BoxFit.fill,
                      ),
                    ),
                    Text('HAMBURGER  35₺'),
                  ],
                ),
              ),
              Card(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    SizedBox(
                      width: 100,
                      height: 100,
                      child: Image.network(
                        'https://images.unsplash.com/photo-1625679647461-d531a609a0c0?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=387&q=80',
                        fit: BoxFit.fill,
                      ),
                    ),
                    Text('COLA  5₺'),
                  ],
                ),
              ),
              SizedBox(height: 100),
              Card(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    new GestureDetector(
                      child: SizedBox(
                        height: 150,
                        width: 150,
                        child: const DecoratedBox(
                          decoration: const BoxDecoration(
                            color: Colors.white,
                            image: DecorationImage(
                                image: NetworkImage(
                                    'https://www.zdalighting.com/wp-content/uploads/sites/190/2016/05/payment-icon.png')),
                          ),
                        ),
                      ),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const Preparation()),
                        );
                      },
                    ),
                    new GestureDetector(
                      child: SizedBox(
                        height: 150,
                        width: 150,
                        child: const DecoratedBox(
                          decoration: const BoxDecoration(
                            color: Colors.white,
                            image: DecorationImage(
                                image: NetworkImage(
                                    'https://ccinfo.unc.edu/wp-content/uploads/sites/219/2018/02/credit-card.png')),
                          ),
                        ),
                      ),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => PaymentPage()),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        color: appBarBackgroundColor,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            SizedBox(height: 55),
            Text(
              '       Total: 30₺',
              style: (TextStyle(fontSize: 20, color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }
}

class PaymentPage extends StatefulWidget {
  @override
  State<PaymentPage> createState() => _PaymentPageState();
}

class _PaymentPageState extends State<PaymentPage> {
  @override
  void initState() {
    disableCapture();
    super.initState();
  }

  secureScreen() async {
    await FlutterWindowManager.addFlags(FlutterWindowManager.FLAG_SECURE);
  }

  unsecure() async {
    await FlutterWindowManager.clearFlags(FlutterWindowManager.FLAG_SECURE);
  }

  @override
  @override
  void dispose() {
    // TODO: implement dispose
    unsecure();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: Colors.amber,
        title: (const Text(
          'Payment',
          style: appBarTextStyle,
        )),
      ),
      body: SingleChildScrollView(
        child: new Column(
          children: <Widget>[
            GestureDetector(
              child: Container(
                child: new Center(
                    child: new Column(children: [
                  new TextFormField(
                    decoration: new InputDecoration(
                      labelText: "Enter Name",
                      fillColor: Colors.white,
                      border: new OutlineInputBorder(
                        borderRadius: new BorderRadius.circular(25.0),
                        borderSide: new BorderSide(),
                      ),
                    ),
                    validator: (val) {
                      if (val!.length == 0) {
                        return "Name cannot be empty";
                      } else {
                        return null;
                      }
                    },
                    keyboardType: TextInputType.text,
                    style: new TextStyle(
                      fontFamily: "Poppins",
                    ),
                  ),
                ])),
              ),
            ),
            Container(
              child: new Center(
                  child: new Column(children: [
                new TextFormField(
                  decoration: new InputDecoration(
                    labelText: "Enter Cart ID",
                    fillColor: Colors.white,
                    border: new OutlineInputBorder(
                      borderRadius: new BorderRadius.circular(25.0),
                      borderSide: new BorderSide(),
                    ),
                  ),
                  validator: (val) {
                    if (val!.length == 0) {
                      return "Cart ID cannot be empty";
                    } else {
                      return null;
                    }
                  },
                  keyboardType: TextInputType.text,
                  style: new TextStyle(
                    fontFamily: "Poppins",
                  ),
                ),
              ])),
            ),
            Container(
              child: new Center(
                  child: new Column(children: [
                new TextFormField(
                  decoration: new InputDecoration(
                    labelText: "Enter CVV",
                    fillColor: Colors.white,
                    border: new OutlineInputBorder(
                      borderRadius: new BorderRadius.circular(25.0),
                      borderSide: new BorderSide(),
                    ),
                  ),
                  validator: (val) {
                    if (val!.length == 0) {
                      return "CVV cannot be empty";
                    } else {
                      return null;
                    }
                  },
                  keyboardType: TextInputType.text,
                  style: new TextStyle(
                    fontFamily: "Poppins",
                  ),
                ),
              ])),
            ),
            Container(
              child: new Center(
                  child: new Column(children: [
                new TextFormField(
                  decoration: new InputDecoration(
                    labelText: "Enter Expiration Date",
                    fillColor: Colors.white,
                    border: new OutlineInputBorder(
                      borderRadius: new BorderRadius.circular(25.0),
                      borderSide: new BorderSide(),
                    ),
                    //fillColor: Colors.green
                  ),
                  validator: (val) {
                    if (val!.length == 0) {
                      return "Expiration Date cannot be empty";
                    } else {
                      return null;
                    }
                  },
                  keyboardType: TextInputType.text,
                  style: new TextStyle(
                    fontFamily: "Poppins",
                  ),
                ),
              ])),
            ),
            Container(
                alignment: Alignment.centerLeft,
                width: 300,
                height: 200,
                margin: EdgeInsets.fromLTRB(60, 60, 60, 20),
                decoration: BoxDecoration(
                  color: Colors.grey[350],
                  image: DecorationImage(
                    image: NetworkImage(
                        'https://www.vippng.com/png/detail/424-4249192_credit-card-design-and-collaterals-black-credit-card.png'),
                    fit: BoxFit.fitWidth,
                  ),
                )),
            new RaisedButton(
              color: Colors.white,
              child: Container(
                alignment: Alignment.center,
                width: 150,
                height: 40,
                margin: EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.amber,
                ),
                child: Text(
                  '   Validate',
                  style: TextStyle(fontSize: 20, color: Colors.white),
                ),
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MapScreen()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> disableCapture() async {
    //disable screenshots and record screen in current screen
    await FlutterWindowManager.addFlags(FlutterWindowManager.FLAG_SECURE);
  }
}
