Group 7 Submission Part D

#Security Features:
->  payment.dart prevents screenshot, including in external devices
->  In login.dart, auth.dart and storage.dart; used flutter_secure_storage to store securely user email and password,

#Notifications:
->  Track Your Meal page --> Tap on each step, app sends notifications accordingly.
        such as; "Your order is taken successfully"
                 "Your order will be ready soon!"
                 "Your meal is ready, hurry before it gets cold!"
                 "Don't forget to Rate your service!"
#Extras:
->  Battery notation --> After logging in, tap on the DropDownMenu at the top-right corner, tap on "Show Battery"
->  Login status is saved and appears in console after logging in
->  Splash screen at the very beginning
->  App icon added