package com.example.restaurant_comp205

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
